const words = {
    easy: ["apple", "berry", "lemon"],
    intermediate: ["android", "bottle", "candle"],
    advanced: ["elephant", "dinosaur", "chocolate"]
};

let currentWord = "";
let level = "easy";

document.getElementById("level-select").addEventListener("change", function() {
    level = this.value;
    setupGame();
});

document.getElementById("guess-btn").addEventListener("click", function() {
    const guess = document.getElementById("guess-input").value;
    checkGuess(guess);
});

function setupGame() {
    const wordList = words[level];
    currentWord = wordList[Math.floor(Math.random() * wordList.length)];
    const grid = document.getElementById("wordle-grid");
    grid.innerHTML = "";
    grid.style.gridTemplateColumns = `repeat(${currentWord.length}, 40px)`;
    for (let i = 0; i < currentWord.length; i++) {
        const cell = document.createElement("div");
        grid.appendChild(cell);
    }
    document.getElementById("guess-input").maxLength = currentWord.length;
    document.getElementById("guess-input").value = "";
}

function checkGuess(guess) {
    const cells = document.getElementById("wordle-grid").children;
    for (let i = 0; i < currentWord.length; i++) {
        cells[i].textContent = guess[i] || "";
        cells[i].style.backgroundColor = guess[i] === currentWord[i] ? "green" : "red";
    }
}

setupGame();